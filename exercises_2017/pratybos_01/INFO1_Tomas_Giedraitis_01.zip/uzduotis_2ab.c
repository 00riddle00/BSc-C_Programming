#include <stdio.h>

int main(int argc, char argv[]) {
    char name[] = "Tomas";
    char surname[] = "Giedraitis";
    int year = 1;
    int group = 1;

    printf("\n");
    printf("%s %s, %d year, %d group\n", name, surname, year, group);
    printf("\n");

    printf(" ____  _     _     _ _\n");
    printf("|  _ \\(_) __| | __| | | ___ \n");
    printf("| |_) | |/ _` |/ _` | |/ _ \\\n");
    printf("|  _ <| | (_| | (_| | |  __/\n");
    printf("|_| \\_\\_|\\__,_|\\__,_|_|\\___|\n");

    printf("\n");

}
