int test();

int main(){
	test();
	return 0;	
}
