#include <stdio.h>
#include <stdlib.h>


void print(char *message);
