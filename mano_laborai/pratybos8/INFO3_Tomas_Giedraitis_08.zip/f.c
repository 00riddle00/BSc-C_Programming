#include <stdio.h>
#include <stdlib.h>

#include "f.h"

void print(char *message) {
    printf("%s\n", message);
}
